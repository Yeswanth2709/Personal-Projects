import mcp.server.fastmcp as fastmcp
import asyncio
from typing import List

# 1. Initialize the FastMCP object
mcp = fastmcp.FastMCP("LocalMathTools")

# 2. Define tools using the @mcp.tool() decorator
@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

@mcp.tool()
def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b

# 3. Define the main function to run the server
def main():
    print("Starting local MCP server (STDIO transport)...")
    # Run the server using the 'stdio' transport for local execution
    # This allows the client to communicate using standard input/output
    mcp.run(transport="streamable-http")

if __name__ == "__main__":
    main()