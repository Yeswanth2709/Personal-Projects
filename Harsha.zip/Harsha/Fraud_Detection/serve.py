import time, json
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from DataClassModels.product_review import ProductReview
from concurrent.futures import ThreadPoolExecutor
from Agents.fraud_detection_agent import FraudCommentDetection
from Agents.models import classify

app = FastAPI()
executor = ThreadPoolExecutor(max_workers=5)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8009/test.html"],
    allow_credentials=True,
    allow_methods=["*"], # Allows all methods (GET, POST, etc.)
    allow_headers=["*"], # Allows all headers
)

@app.middleware("http")
async def guarded_generate(request: Request, call_next):
    if "user-review" in str(request.url):
        print(await request.body())
        comment = json.loads(await request.body())
        label = classify(f'Review Heading:{comment["review"]["review_heading"]}' + "\n\n" + f'Review: {comment["review"]["review_text"]}')
        if label=='JAILBREAK_ATTEMPT':
            return "This appears to be a jailbreak attempt. I can't continue. Please rewrite your message in a normal safe way."
        if label == 'HARMFUL_REQUEST':
            return "I can help with safe and legal topics only. Please rephrase your input so I can help safely"
        response = await call_next(request)
        return response
    return await call_next(request)

fcd = FraudCommentDetection()

@app.post("/user-review", status_code=200, )
async def review(input_data: ProductReview):
    """
    A POST endpoint that accepts an Item object.
    This request will pass through all the configured middlewares.
    """
    input_data = input_data.model_dump()
    input_data["timestamp"]=time.perf_counter()
    # executor.submit(fcd.process, input_data)
    fcd.process(input_data=input_data)
    return {"message": "ok"}

@app.get("/get-numeric-stats")
async def stats():
    return {}