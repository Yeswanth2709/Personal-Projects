# import base64, os
# import httpx
# from langchain_openai import ChatOpenAI
# from langchain.messages import HumanMessage, SystemMessage, AIMessage

# llm = ChatOpenAI(
#  base_url="https://genailab.tcs.in",
#  model="azure/genailab-maas-gpt-4o",
#  api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
#  http_client=httpx.Client(verify=False)
# )

# def encode_image(image_path):
#     with open(image_path, "rb") as f:
#         return base64.b64encode(f.read()).decode("utf-8")
    
# # for i in os.listdir(r"C:\Users\GenAIHYDSYPUSR40\Desktop\Harsha\fraud_detection\negatives\\"):
# #     print(i)
# image_base64 = encode_image(r"C:\Users\GenAIHYDSYPUSR40\Desktop\Harsha\fraud_detection\{i}".format(i="Gemini_Generated_Image_fhq1zyfhq1zyfhq1.png"))
# llm.bind_tools([],strict=True)
# print(r"C:\Users\GenAIHYDSYPUSR40\Desktop\Harsha\fraud_detection\negatives\{i}".format(i="Gemini_Generated_Image_4vpykm4vpykm4vpy.png"))

# response = llm.invoke([
#     SystemMessage(content="You are a fraud detector, You are given an image to verify. Analyse the image and tell us whether it is fake or not. Give your output in JSON as below.\n\n{fraud:Yes or No, reason: tell how you classified}"),
#     HumanMessage(content=[
#         {"type": "text", "text": "From the provided image tell me whether it is fake or not?"},
#         {
#             "type": "image_url",
#             "image_url": {
#                 "url": f"data:image/png;base64,{image_base64}"
#             }
#         }
#     ])
# ])

# print(response.content)
# print("================================")



# from openai import OpenAI
# import httpx

# client = OpenAI(http_client=httpx.Client(verify=False), api_key="sk-QibkR-xrOxD2AsMgdaL0Pg", base_url="https://genailab.tcs.in")
# with open(r"C:\Users\GenAIHYDSYPUSR40\Desktop\Harsha\fraud_detection\9154a9cf-4df6-493e-8af6-d20f6f702a7a.wav","rb") as f:
#     response = client.audio.transcriptions.create(
#         file=f,
#         model="azure/genailab-maas-whisper"
#     )
#     with open("transcribe.txt", "w") as b:
#         b.write(response.text)


# from pathlib import Path

# file_path = Path(__file__)
# file_path = file_path.parent.parent.joinpath("langgraph.db")
# print(file_path)
# print(file_path.touch(exist_ok=True))

# import base64

# def encode_image_to_base64(path):
#     """Read an image file and return Base64 string."""
#     with open(path, "rb") as img:
#         return base64.b64encode(img.read()).decode("utf-8")   

import requests

response = requests.post("")