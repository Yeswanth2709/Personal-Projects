from pydantic import BaseModel
from pydantic.fields import Field


class Reivew(BaseModel):
    rating: float   
    review_heading: str = Field(default="", max_length=100)
    review_text: str = Field(default="", max_length=500)
    image: list


class ProductReview(BaseModel):
    device: str
    os: str
    product_id: str
    user_id: str
    review: Reivew
    