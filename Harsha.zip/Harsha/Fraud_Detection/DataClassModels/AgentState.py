from typing_extensions import TypedDict
from .product_review import ProductReview
from langchain.messages import AnyMessage

class AgentState(TypedDict):
    user_input: dict
    output: AnyMessage
    stats: AnyMessage
    evaluations: list