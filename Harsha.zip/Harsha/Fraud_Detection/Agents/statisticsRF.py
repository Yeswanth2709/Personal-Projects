import httpx
import asyncio, nest_asyncio

from langchain_openai import ChatOpenAI
from .Prompts.statGenerator import system, user
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.messages import HumanMessage, SystemMessage, AIMessage, ToolMessage


table = {"user_3775": 237,
"user_3640": 168,
"user_0493": 12391,
"user_2536": 20999}

client = MultiServerMCPClient({
    "XGBoost":{
        "url":"http://127.0.0.1:8002/mcp",
        "transport": "streamable_http"
    }
})

nest_asyncio.apply()
tools = asyncio.get_running_loop().run_until_complete(client.get_tools())
tools_name = {i.name:i for i in tools}

stat_generator = ChatOpenAI(
 base_url="https://genailab.tcs.in",
 model="azure/genailab-maas-gpt-4o",
 api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
 http_client=httpx.Client(verify=False)
)#.bind_tools(tools)

def fetch_from_tools(output: AIMessage, state):
    result = []
    for i in output.tool_calls:
        i["args"]["id"] = table[state["user_input"]["user_id"]]
        result.append(
            ToolMessage(content = asyncio.run(tools_name[i["name"]].ainvoke(i["args"])),
                        tool_call_id=i["id"],
                        name=i["name"])
            )


    return result


def fetch_statistics(state):
    llm = stat_generator.bind_tools(tools=tools)
    output = llm.invoke(
        [
            SystemMessage(system),
            AIMessage("Here is a deep review of the image:\n\n"+state["output"].content),
            HumanMessage(user),

        ]
    )

    results = [
        SystemMessage(system),
        HumanMessage(user),
        output
    ]
    while output.tool_calls:
        results.extend(fetch_from_tools(output, state))
        output = stat_generator.invoke(results)
    return {"stats":results[-1].content}