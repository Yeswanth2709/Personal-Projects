####################### Comment Detector ############################

detect_comment = """You are given a user product review, tell me it is fake or not. analyse the images provided. another llm has identified whether it is fake or not consider that as well."""

######################### Comment detector reasoning prompt #####################


#################### Human Review #################

comment= """
Here is the user provided review for the product.

Review Heading: 
{review_heading}

Review:
{review_text}

images:
{image_description}


"""