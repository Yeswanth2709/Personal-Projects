############################# System message ##################

system = """You need to generate statistics in JSON format about user data. So that with authenticity of user we can get to know the given review is valid or not."""

########################## System Message Over #####################


########################## User prompt ######################

user = """You need to give the output in strict JSON format with details like whether is user is verified or not, what is the device user used, from where the user created the review, etc"""