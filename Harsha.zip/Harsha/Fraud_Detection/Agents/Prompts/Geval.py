Evaluation_prompt = """
You are an evaluator model. 
Evaluate the RESPONSE to the USER_QUERY based on the given evaluation dimension:
Dimension: {dimension}

Scoring rules:
- Output MUST be ONLY valid JSON
- "score" MUST be an single integer 1 to 10.
- "explaination" MUST be a short 2-4 line textual justification.
- No extra text outside JSON. No markdown

USER_QUERY:
{query}

RESPONSE:
{answer}
**NO PREAMBLE**
Return ONLY JSON in the following exact format:
{{
    "score": <integer between 1 and 10>,
    "explaination": "<short explaination>"
}}"""