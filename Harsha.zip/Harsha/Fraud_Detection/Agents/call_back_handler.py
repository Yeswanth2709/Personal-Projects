# from langchain_core.callbacks import BaseCallbackHandler
# from langchain_core.outputs.llm_result import LLMResult

# class AfterLLMCallbackHandler(BaseCallbackHandler):
#     def __init__(self, callback_function):
#         """
#         callback_function: a function to be called after the LLM finishes.
#         It should accept one argument: the LLM output text.
#         """
#         self.callback_function = callback_function

    


# # Example usage
# def my_post_llm_function(output_text):
#     print("LLM has finished. Output:")
#     print(output_text)
#     # You can put any custom logic here

# # Instantiate the handler
# callback_handler = AfterLLMCallbackHandler(my_post_llm_function)

# # Use with LLM
# from langchain.chat_models import ChatOpenAI
# from langchain.callbacks import CallbackManager

# callback_manager = CallbackManager([callback_handler])
# llm = ChatOpenAI(model_name="gpt-4", callback_manager=callback_manager)

# # Run LLM
# response = llm("Hello! Tell me a fun fact.")
