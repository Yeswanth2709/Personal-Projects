import re, httpx
import sqlite3
import json
from pathlib import Path

from langchain_openai import ChatOpenAI
from langchain.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver

from DataClassModels.AgentState import AgentState
from .statisticsRF import fetch_statistics
from .Prompts.translator import translator_prompt
from .Prompts.commentDetector import detect_comment, comment
from .models import translate_model, Image_Detector, Comment_Detector, GPT_4o


def geval_score(query,answer,dimension,context=None):
    if context:
        context_text = f"\n\nContext:\n{context}"
    else:
        context_text = f""
    prompt = f"""
            You are an evaluator model. 
            Evaluate the RESPONSE to the USER_QUERY based on the given evaluation dimension:
            Dimension: {dimension}
            
            Scoring rules:
            - Output MUST be ONLY valid JSON
            - "score" MUST be an single integer 1 to 10.
            - "explaination" MUST be a short 2-4 line textual justification.
            - No extra text outside JSON. No markdown
            
            USER_QUERY:
            {query}

            RESPONSE:
            {answer}
	    **NO PREAMBLE**
            Return ONLY JSON in the following exact format:
            {{
                "score": <integer between 1 and 10>,
                "explaination": "<short explaination>"
            }}
    """
    raw = GPT_4o.invoke(prompt)
    #print("Debug",raw.content)
    try:
        data = json.loads(raw.content)
        return data
    except Exception as e:
        print("Something wrong")
        return {"score":7,"description":"The answer and query seems to be good"}

def extract(i: str, j:int):
    description = Image_Detector.invoke(
        [   
            SystemMessage(
        content=(
            "You are an expert model for detecting AI-generated fake review images. "
            "Classify whether the image is AI-generated ('yes' or 'no') and explain your reasoning. "
            "Respond ONLY in valid JSON format exactly like this:\n"
            "{\n"
            "  \"fraud\": \"yes\" or \"no\",\n"
            "  \"explainability\": \"your explanation in human tone\"\n"
            "  \"image_description\": \"Image description\""
            "}\n"
            "Do not include anything outside the JSON object."
        )
    ),
            HumanMessage(content=[
                {"type": "text", "text": "**NO PREAMBLE** Analyze the image thoroughly and provide the JSON output."},
                {
                    "type": "image_url",
                    "image_url": {
                        "url": i
                    }
                }
            ])
        ]
    )
    image_description = f"""<image {j}>
{description}
</image {j}>"""
    return image_description

def extract_images(images: list):
    extracted_images = []
    for j,i in enumerate(images):
        extracted_images.append(extract(i, j+1))
    return "\n\n".join(extracted_images)

class FraudCommentDetection:

    def __init__(self):
        pass

    def translate_to_english(self, text: str):
        return translate_model.invoke(
            [
                SystemMessage(translator_prompt),
                HumanMessage(content=text)
            ]
        ).content
    
    def detect_comment(self, state):
        state
        heading = state["user_input"]["review"]["review_heading"]
        review = state["user_input"]["review"]["review_text"]
        image = state["user_input"]["review"]["image"]
        output = Comment_Detector.invoke(
            [
                SystemMessage(detect_comment),
                HumanMessage(comment.format(review_heading=heading,
                                                    review_text=review,
                                                    image_description=image))
            ]
        )
        return {"output":output}
        

    def contains_non_english(self, text: str) -> bool:
        english_pattern = r'[^a-zA-Z0-9\s.,?!:;\'"()\[\]{}\-+/&@#$%^=*~<>]'
        if re.search(english_pattern, text):
            return True
        else:
            return False
        
    def evaluate(self, state):        
        query = state["user_input"]["review"]["review_heading"] + "\n\n" + state["user_input"]["review"]["review_text"]

        answer = state["stats"]
        faithfulness_score = geval_score(query,answer,"faithfulness")
        completeness_score = geval_score(query,answer,"completeness")
        coherence_score = geval_score(query,answer,"coherence")

        return {"evaluations":[faithfulness_score,completeness_score,coherence_score]}

        
    def build_graph(self):
        graph = StateGraph(AgentState)

        graph.add_node("commenter",self.detect_comment)
        graph.add_node("concluder",fetch_statistics)
        graph.add_node("evaluator",self.evaluate)
        graph.add_edge("commenter","concluder")
        graph.add_edge("concluder","evaluator")
        graph.add_edge("concluder", END)
        graph.set_entry_point("commenter")
        
        return graph

    def process(self, input_data: dict):
        review_heading = input_data["review"]["review_heading"]
        review_text = input_data["review"]["review_text"]

        if self.contains_non_english(review_heading):
            input_data["review"]["review_heading"] = self.translate_to_english(review_heading)
        
        if self.contains_non_english(review_text):
            input_data["review"]["review_text"] = self.translate_to_english(review_text)

        input_data["review"]["image"] = extract_images(input_data["review"]["image"])
        

        graph = self.build_graph()

        
        file_path = Path(__file__)
        file_path = file_path.parent.parent.joinpath("langgraph.db")
        file_path.touch(exist_ok=True)

        THREAD_ID = input_data["timestamp"]
        config = {"configurable": {"thread_id": THREAD_ID}}
        conn = SqliteSaver(sqlite3.connect(file_path, check_same_thread=False))
        messages={"user_input": input_data}
        graph = graph.compile(checkpointer=conn)

        output = graph.invoke(messages, config=config) 

        conn = sqlite3.connect(file_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        dummy_users = []
        evals=["faithfulness_score","completeness_score","coherence_score"]
        j = 0
        for i in output["evaluations"]:
            dummy_users.append((input_data["user_id"], input_data["product_id"], evals[j], output["evaluations"][j]["score"], output["evaluations"][j]["explaination"]))
            j+=1

        #change db name
        cur.executemany(
            """INSERT OR IGNORE INTO evaluation_test (user_id,product_id,dimension,score,explanation) VALUES (?, ?, ?, ?, ?);""",
            dummy_users
        )

        conn.commit()
        conn.close()


