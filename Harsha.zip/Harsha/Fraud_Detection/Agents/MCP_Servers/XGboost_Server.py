import json
import mcp.server.fastmcp as fastmcp
import random
from pathlib import Path

import sqlite3
# import pandas as pd
# import xgboost as xgb


mcp = fastmcp.FastMCP("XGBoost Model MCP",port=8002, host="127.0.0.1")
# -------------------------
#   MCP Tool
# -------------------------

def classify_xgboost(i):

    file_path = Path(__file__)
    file_path = file_path.parent.parent.parent.joinpath("langgraph.db")
    DB_PATH = file_path

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    
    loaded_booster = xgb.Booster()
    file_path = "xgboost_best.pkl"
    loaded_booster.load_model(file_path)
    cur.execute("SELECT * FROM user where user_id=?", (i,))
    single_row_data = dict(cur.fetchall()[0])
    single_row_data = pd.DataFrame(single_row_data)
    X_test_dmatrix = xgb.DMatrix(single_row_data)
    return loaded_booster.predict(X_test_dmatrix)

@mcp.tool(
    name="XGBoost_Model",
    description="Fetch all users from the local SQLite DB and return JSON.",
)
def fetch_users(id: str):
    """Return users as JSON."""
    fraud_or_not = {"Fraud": random.randint(1,10)}
    return json.dumps(fraud_or_not)  # MCP clients like JSON-as-string


# -------------------------
#  MCP Server Entry
# -------------------------
def main():
    print("Starting local MCP server (HTTP transport)...")
    # Run the server using the 'stdio' transport for local execution
    # This allows the client to communicate using standard input/output
    mcp.run(transport="streamable-http") # Starts the MCP server


if __name__ == "__main__":
    main()
