import json
import sqlite3
import mcp.server.fastmcp as fastmcp

from pathlib import Path

file_path = Path(__file__)
file_path = file_path.parent.parent.parent.joinpath("langgraph.db")
DB_PATH = file_path
mcp = fastmcp.FastMCP("DB Tools to get User data", port=8001, host="127.0.0.1")

# -------------------------
#  SQLite Helper
# -------------------------
def fetch_users_from_db(user_id):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    cur.execute("SELECT * FROM user where user_id=?", (user_id,))
    result = dict(cur.fetchall()[0])


    result.pop("user_id")
    
    conn.close()
    return result


# -------------------------
#   MCP Tool
# -------------------------
@mcp.tool(
    name="fetch_users",
    description="Fetch all users from the local SQLite DB and return JSON.",
)
def fetch_users(user_id):
    """Return users as JSON."""
    users = fetch_users_from_db(user_id)
    return json.dumps(users)  # MCP clients like JSON-as-string


# -------------------------
#  MCP Server Entry
# -------------------------
def main():
    print("Starting local MCP server (HTTP transport)...")
    # Run the server using the 'stdio' transport for local execution
    # This allows the client to communicate using standard input/output
    mcp.run(transport="streamable-http") # Starts the MCP server


if __name__ == "__main__":
    main()
    # print(fetch_users("user_1"))
