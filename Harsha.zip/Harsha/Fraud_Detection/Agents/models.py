import httpx
from langchain_openai import ChatOpenAI
from langchain.messages import AIMessage
from langchain_core.messages import BaseMessage
from typing import Any, List, Optional, Union

from .Prompts.Guardrail import classifier_prompt

GPT_4o = ChatOpenAI(
 base_url="https://genailab.tcs.in",
 model="azure/genailab-maas-gpt-4o",
 api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
 http_client=httpx.Client(verify=False)
)

def classify(prompt):
    prompt = classifier_prompt.format(prompt=prompt)
    print(prompt)
    return GPT_4o.invoke(classifier_prompt).content

def validate_output(output):
    label = classify(output)
    if label!='SAFE':
        return "Output Blocked due to unsafe content"
    return output

class ModifiableChatModel(ChatOpenAI):
    def invoke(
        self,
        prompt: Union[str, List[BaseMessage]],
        config: Optional[Any] = None,
        **kwargs: Any
    ) -> AIMessage:
        # Call the original invoke (super) to get the real response
        original_ai_msg: AIMessage = super().invoke(prompt, config=config, **kwargs)
        
        # Modify the content (e.g. append a suffix, or transform text)
        new_content = validate_output(original_ai_msg.content)
        
        # Build a new AIMessage with the modified content and preserve metadata
        modified_msg = AIMessage(
            content=new_content,
            response_metadata=original_ai_msg.response_metadata,
            additional_kwargs=original_ai_msg.additional_kwargs,
            tool_calls=getattr(original_ai_msg, "tool_calls", None),
        )
        
        return modified_msg

translate_model = ModifiableChatModel(
 base_url="https://genailab.tcs.in",
 model="azure/genailab-maas-gpt-4o-mini",
 api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
 http_client=httpx.Client(verify=False)
)

Comment_Detector = ModifiableChatModel(
 base_url="https://genailab.tcs.in",
 model="azure/genailab-maas-gpt-4o",
 api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
 http_client=httpx.Client(verify=False)
)

Image_Detector = ModifiableChatModel(
 base_url="https://genailab.tcs.in",
 model="azure/genailab-maas-gpt-4o",
 api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
 http_client=httpx.Client(verify=False)
)