@echo off
set "a=%*"
pip install %a%
echo %a% >> req.txt