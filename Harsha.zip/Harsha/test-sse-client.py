import requests
import json
import time

# NOTE: The SSE client needs to be smart enough to parse the special SSE formatting.
# The `requests` library just gives us the raw bytes/lines.

def sse_client(url: str):
    """
    Connects to an SSE endpoint and parses the incoming events.
    
    Uses `stream=True` to keep the connection open and read the data 
    as it arrives.
    """
    print(f"Connecting to SSE stream at: {url}")
    
    try:
        # Use 'stream=True' to keep the connection open
        with requests.get(url, stream=True) as response:
            
            # Raise an error for bad status codes
            response.raise_for_status()
            
            # Start tracking the current event data
            current_event = {}
            
            # Iterate over the response lines as they come in
            # iter_lines() is useful for streaming text data
            for line in response.iter_lines(decode_unicode=True):
                
                # Check for a connection close
                if line is None:
                    continue
                
                # 1. The stream ends with an empty line (two newlines `\n\n`)
                if not line:
                    if current_event:
                        # Process the complete event
                        print(f"--- 📣 RECEIVED EVENT ---")
                        print(f"Event ID:   {current_event.get('id', 'N/A')}")
                        print(f"Event Type: {current_event.get('event', 'message')}")
                        print(f"Data:       {current_event.get('data')}")
                        print("--------------------------\n")
                        current_event = {}
                    continue
                
                # 2. Lines start with field names followed by a colon
                if ':' in line:
                    field, value = line.split(':', 1)
                    field = field.strip()
                    value = value.lstrip() # Leading space is optional but good practice

                    if field == 'data':
                        # The 'data' field can contain multi-line data
                        # We append to ensure we handle it correctly
                        # For this example, we just overwrite as we only send single lines
                        current_event['data'] = value
                    elif field == 'event':
                        current_event['event'] = value
                    elif field == 'id':
                        current_event['id'] = value
                    elif field == 'retry':
                        # Handle retry logic if needed, but not necessary for this example
                        pass

    except requests.exceptions.RequestException as e:
        print(f"\n--- 🛑 ERROR ---")
        print(f"An error occurred during the connection: {e}")
        print("-----------------")

if __name__ == "__main__":
    # Ensure the server is running on this address
    STREAM_URL = "http://127.0.0.1:8009/stream"
    sse_client(STREAM_URL)
    print("Client finished. Connection closed by server.")