from langchain_openai import ChatOpenAI, OpenAI
import httpx, asyncio
API_KEY = "sk-E1TXA6DgfwF8pN1m5Fiy4g"

llm = ChatOpenAI(
    model="azure/genailab-maas-gpt-4o",
    base_url="https://genailab.tcs.in",
    http_client=httpx.Client(verify=False),
    http_async_client=httpx.AsyncClient(verify=False),
    api_key=API_KEY,
    # verify=False
)


import asyncio
import os
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.sessions import StdioServerParameters

# Make sure you have your OpenAI API key set as an environment variable
# os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"

async def run_agent():
    # 1. Define the parameters for starting the local MCP server process
    # This tells the client how to start the 'mcp_server.py' script
    server_params = {
        "math": StdioServerParameters(
            command="python",
            args=["test_mcp.py"],
        ),
        "transport":"strstdio"
    }

    # 2. Create a client to connect to the server(s)
    # This client handles the connection and tool discovery
    client = MultiServerMCPClient({
        "math":{
            "url":"http://127.0.0.1:8000/mcp",
            "transport": "streamable_http"
        }
    })
    
    # 3. Load the tools from the local server
    tools = await client.get_tools()
    print(f"Loaded {len(tools)} tool(s) from local MCP server: {[t.name for t in tools]}")
    
    print(await tools[1].ainvoke({"a":5,"b":2}))
    
    # 4. Define the LLM
    llm = ChatOpenAI(
        model="azure/genailab-maas-gpt-4o",
        base_url="https://genailab.tcs.in",
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False),
        api_key=API_KEY,
        # verify=False
    )

if __name__ == "__main__":
    # Use nest_asyncio if running in a Jupyter/IPython environment
    # import nest_asyncio
    # nest_asyncio.apply()
    
    asyncio.run(run_agent())