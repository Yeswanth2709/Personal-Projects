import os, httpx
from typing import Annotated, TypedDict
from langchain_core.messages import AnyMessage, HumanMessage
from langgraph.graph import StateGraph
from langgraph.checkpoint.sqlite import SqliteSaver
from langchain_openai import ChatOpenAI
import sqlite3

llm = ChatOpenAI(
    model="azure/genailab-maas-gpt-4o",
    base_url="https://genailab.tcs.in",
    api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
    # verify=False
)

# 1. Define the Graph State
class AgentState(TypedDict):
    """The state of the graph, storing conversation history."""
    messages: Annotated[list[AnyMessage], lambda x, y: x + y]

# 2. Define the SqliteSaver
# Specify the file name for the SQLite database. If it doesn't exist, it will be created.
DB_FILE = r"C:\Users\GenAIHYDSYPUSR39\Documents\harsha\langgraph_chat_history.sqlite"
conn = SqliteSaver(sqlite3.connect(DB_FILE, check_same_thread=False))

# 3. Define the LLM Node (example using a simple repeater for demonstration)
# In a real application, this would call your LLM
def call_llm(state: AgentState):
    """A node that processes the input and generates a response."""
    # Get the last message from the list
    last_message = state["messages"][-1].content
    
    # In a real agent, you would call LLM here:
    llm_response = llm.invoke(state["messages"])
    
    return {"messages": [llm_response]}

# 4. Build and Compile the Graph with the Checkpointer
workflow = StateGraph(AgentState)
workflow.add_node("llm", call_llm)
workflow.set_entry_point("llm")
workflow.set_finish_point("llm")

# Compile the graph, passing the SqliteSaver instance to the checkpointer 

app = workflow.compile(
    checkpointer=conn,
    # For a simple linear graph, the entry point is also the finish point
    # but for a stateful chat, you often want to re-enter the main node.
)

# 5. Run the Graph using a Thread ID
# The 'thread_id' is the key used by the checkpointer to save/load history.

THREAD_ID = "user_12345" 
config = {"configurable": {"thread_id": THREAD_ID}}

print(f"--- First run for thread ID: {THREAD_ID} ---")
# The initial message will be saved to the database.
# The graph state is loaded from the DB, and the new messages are added.
messages={"messages": [HumanMessage(content=input("Enter query :: "))]}
for chunk, metadata in app.stream(
    input=messages,
    config=config,
    stream_mode="messages"
):
    print(chunk.content)

# print("Graph State after Run 2:", result2["messages"][-1].content)