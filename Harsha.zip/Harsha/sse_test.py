import asyncio
from fastapi import FastAPI
from starlette.responses import StreamingResponse

# 💡 Use a descriptive tag to fetch a relevant diagram of the components working together
# 

app = FastAPI(
    title="FastAPI SSE Streamer",
    description="Streams events to clients using Server-Sent Events (SSE).",
)

# Function to format data into the SSE protocol
def format_sse(data: str, event: str = 'message', id: int = None) -> str:
    """Formats data into the Server-Sent Events (SSE) protocol format."""
    msg = f'event: {event}\n'
    if id is not None:
        msg += f'id: {id}\n'
    msg += f'data: {data}\n\n'
    return msg

async def event_generator():
    """Generates a stream of events."""
    count = 0
    max_events = 15
    print(f"Starting SSE stream: Will send {max_events} events.")
    
    while count < max_events:
        await asyncio.sleep(1)  # Wait for 1 second
        count += 1
        
        # The data being sent
        data = f"Event number {count}"
        
        # Format and yield the SSE string
        yield format_sse(data=data, event="update", id=count)
        
        print(f"Server sent: {data}")

@app.get("/chat")
async def sse_endpoint():
    """Endpoint for Server-Sent Events (SSE)."""
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
    )

# Optional root endpoint
@app.get("/")
def read_root():
    return {"message": "Visit /stream to start the SSE connection."}


@app.get("/get")
def read_root():
    return {"message": "Visit /stream to start the SSE connection."}