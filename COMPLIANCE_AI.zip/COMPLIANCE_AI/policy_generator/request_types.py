REQUEST_TYPES = {
    "PatientTriage": {
        "regulations": [
            "HIPAA",
            "GDPR",
            "CCPA",
            "EU_AI_ACT"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Data Minimization",
            "Security",
            "Governance and Accountability"
        ]
    },

    "ClinicalDecisionSupport": {
        "regulations": [
            "HIPAA",
            "GDPR",
            "EU_AI_ACT"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Explainability",
            "Governance and Accountability",
            "Security"
        ]
    },

    "BillingAndClaims": {
        "regulations": [
            "HIPAA",
            "PCI_DSS",
            "GDPR",
            "CCPA"
        ],
        "principles": [
            "Access Control",
            "Data Minimization",
            "Retention",
            "Security"
        ]
    }
}
