import pickle
from pathlib import Path
from typing import Dict, List

from policy_generator.policy_graph.policy_engine.policy_query import (
    get_enforcing_agents,
    get_enforcing_agents_with_policies,
)

# ==========================================================
# LOAD POLICY GRAPH (ONCE)
# ==========================================================
BASE_DIR = Path(__file__).resolve().parent.parent.parent
GRAPH_PATH = BASE_DIR / "policy_graph" / "policy_graph.pkl"

if not GRAPH_PATH.exists():
    raise FileNotFoundError(f"Policy graph not found: {GRAPH_PATH}")

with open(GRAPH_PATH, "rb") as f:
    POLICY_GRAPH = pickle.load(f)

# ==========================================================
# AGENT → ACTION MAPPING
# ==========================================================
AGENT_ACTIONS = {
    "AccessControlAgent": ["check_role_permissions"],
    "PrivacyAgent": ["mask_phi", "anonymize_input"],
    "OutputGuardAgent": ["scan_output", "redact_pii"],
    "AuditAgent": ["log_decision", "record_policy_path"],
    "PolicyAgent": ["fallback_governance"],
}

# ==========================================================
# CANONICAL EXECUTION ORDER
# ==========================================================
AGENT_ORDER = {
    "AccessControlAgent": 1,
    "PrivacyAgent": 2,
    "TaskAgent": 3,          # injected later by router
    "OutputGuardAgent": 4,
    "AuditAgent": 5,
    "PolicyAgent": 99,
}

# ==========================================================
# AI_SCOPE → AGENT MAPPING (ROBUST FIX)
# ==========================================================
AI_SCOPE_TO_AGENT = {
    "AI_Privacy_Control": "PrivacyAgent",
    "AI_Access_Control": "AccessControlAgent",
    "AI_Governance": "AuditAgent",
    "AI_Explainability": "OutputGuardAgent",
    "General_Governance": "PolicyAgent",
}

# ==========================================================
# BUILD ENFORCEMENT PLAN (GRAPH-INTERNAL)
# ==========================================================
from policy_generator.request_types import REQUEST_TYPES
from policy_generator.policy_graph.policy_engine.policy_query import (
    get_enforcing_agents_with_policies
)

def build_enforcement_plan(request_type: str):
    if request_type not in REQUEST_TYPES:
        raise ValueError(f"Unknown request type: {request_type}")

    regulations = REQUEST_TYPES[request_type]["regulations"]

    enforcement_steps = []
    policy_trace_map = {}

    for regulation in regulations:
        agent_policy_map = get_enforcing_agents_with_policies(regulation)

        for agent, policies in agent_policy_map.items():
            policy_trace_map.setdefault(agent, []).extend(policies)

    for agent, policies in policy_trace_map.items():
        enforcement_steps.append({
            "agent": agent,
            "policy_trace": policies
        })

    return {
        "request_type": request_type,
        "regulations": regulations,
        "enforcement_steps": enforcement_steps,
        "policy_trace_map": policy_trace_map
    }

