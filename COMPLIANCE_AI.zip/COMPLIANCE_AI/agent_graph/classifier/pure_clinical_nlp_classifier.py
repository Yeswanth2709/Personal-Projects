# pure_clinical_nlp_classifier.py

import spacy
import medspacy
import medspacy.section_detection
from medspacy.ner import TargetRule
from medspacy.context import ConTextRule
from medspacy.section_detection import SectionRule
from spacy.tokens import Span

from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

from typing import Dict, List
from dataclasses import dataclass


# =========================================================
# DATA STRUCTURE
# =========================================================

@dataclass
class ClassificationResult:
    request_type: str
    confidence: float
    entities: List[Dict]
    matched_rules: List[str]
    clinical_context: Dict
    scoring_breakdown: Dict


# =========================================================
# CLASSIFIER
# =========================================================

class PureClinicalNLPClassifier:
    """
    Pure clinical NLP classifier:
    - medspaCy (targets + context + sections)
    - scispaCy (biomedical NER)
    - SentenceTransformers (semantic similarity)

    ❌ No regex
    ❌ No LLM / SLM
    """

    def __init__(self, semantic_model: str = "all-MiniLM-L6-v2"):
        print("🔄 Loading medspaCy pipeline...")
        self.nlp = medspacy.load()

        # MUST come before TargetRules
        self._register_span_extensions()

        print("🔄 Loading scispaCy model...")
        try:
            self.sci_nlp = spacy.load("en_ner_bc5cdr_md")
        except Exception:
            print("⚠️  BC5CDR not found, using en_core_sci_sm")
            self.sci_nlp = spacy.load("en_core_sci_sm")

        print(f"🔄 Loading semantic model: {semantic_model}")
        self.semantic_model = SentenceTransformer(semantic_model)

        self._setup_target_matcher()
        self._setup_context_rules()
        self._setup_section_detector()
        self._setup_semantic_exemplars()

        print("🧠 Pipeline:", self.nlp.pipe_names)
        print("✅ Pure clinical NLP classifier ready!")


    # =====================================================
    # SPAN EXTENSIONS
    # =====================================================

    def _register_span_extensions(self):
        if not Span.has_extension("category"):
            Span.set_extension("category", default=None)
        if not Span.has_extension("urgency"):
            Span.set_extension("urgency", default=None)
        if not Span.has_extension("is_phi"):
            Span.set_extension("is_phi", default=False)


    # =====================================================
    # TARGET MATCHER
    # =====================================================

    def _setup_target_matcher(self):
        matcher = self.nlp.get_pipe("medspacy_target_matcher")

        rules = [
            # ---------- TRIAGE ----------
            TargetRule("chest pain", "SYMPTOM", attributes={"category": "PatientTriage"}),
            TargetRule("shortness of breath", "SYMPTOM", attributes={"category": "PatientTriage"}),
            TargetRule("fever", "SYMPTOM", attributes={"category": "PatientTriage"}),
            TargetRule("emergency", "URGENCY", attributes={"category": "PatientTriage"}),
            TargetRule("triage", "PROCESS", attributes={"category": "PatientTriage"}),
            TargetRule("vital signs", "MEASUREMENT", attributes={"category": "PatientTriage"}),

            # ---------- CDS ----------
            TargetRule("diagnosis", "PROCESS", attributes={"category": "ClinicalDecisionSupport"}),
            TargetRule("treatment", "INTERVENTION", attributes={"category": "ClinicalDecisionSupport"}),
            TargetRule("medication", "INTERVENTION", attributes={"category": "ClinicalDecisionSupport"}),
            TargetRule("drug interaction", "SAFETY", attributes={"category": "ClinicalDecisionSupport"}),
            TargetRule("dosage", "DOSING", attributes={"category": "ClinicalDecisionSupport"}),

            # ---------- BILLING ----------
            TargetRule("billing", "ADMINISTRATIVE", attributes={"category": "BillingAndClaims"}),
            TargetRule("insurance", "ADMINISTRATIVE", attributes={"category": "BillingAndClaims"}),
            TargetRule("CPT code", "CODING", attributes={"category": "BillingAndClaims"}),
            TargetRule("ICD-10", "CODING", attributes={"category": "BillingAndClaims"}),
            TargetRule("payment", "FINANCIAL", attributes={"category": "BillingAndClaims"}),
        ]

        for r in rules:
            matcher.add([r])


    # =====================================================
    # CONTEXT
    # =====================================================

    def _setup_context_rules(self):
        context = self.nlp.get_pipe("medspacy_context")
        context.add([
            ConTextRule("denies", "NEGATED_EXISTENCE", direction="forward"),
            ConTextRule("no evidence of", "NEGATED_EXISTENCE", direction="forward"),
            ConTextRule("history of", "HISTORICAL", direction="forward"),
            ConTextRule("possible", "POSSIBLE_EXISTENCE", direction="forward"),
        ])


    # =====================================================
    # SECTIONIZER
    # =====================================================

    def _setup_section_detector(self):
        if "medspacy_sectionizer" not in self.nlp.pipe_names:
            self.nlp.add_pipe("medspacy_sectionizer", last=True)

        sectionizer = self.nlp.get_pipe("medspacy_sectionizer")
        sectionizer.add([
            SectionRule("Patient Information:", "patient_demographics"),
            SectionRule("Contact Details:", "contact_info"),
            SectionRule("Billing Information:", "billing"),
            SectionRule("Insurance:", "insurance"),
        ])


    # =====================================================
    # SEMANTIC EXEMPLARS
    # =====================================================

    def _setup_semantic_exemplars(self):
        self.exemplars = {
            "PatientTriage": [
                "Patient with chest pain and shortness of breath",
                "Emergency triage assessment",
            ],
            "ClinicalDecisionSupport": [
                "Recommend medication dosage",
                "Check drug interactions",
            ],
            "BillingAndClaims": [
                "Insurance claim submission",
                "ICD-10 and CPT billing",
            ],
        }

        self.exemplar_embeddings = {
            k: self.semantic_model.encode(v, show_progress_bar=False)
            for k, v in self.exemplars.items()
        }


    # =====================================================
    # MEDSPACY ANALYSIS
    # =====================================================

    def analyze_with_medspacy(self, text: str) -> Dict:
        doc = self.nlp(text)

        analysis = {
            "entities": [],
            "sections": [],
        }

        for ent in doc.ents:
            analysis["entities"].append({
                "text": ent.text,
                "label": ent.label_,
                "category": ent._.category,

                # ---- context flags (ALWAYS PRESENT) ----
                "is_negated": ent._.is_negated,
                "is_uncertain": ent._.is_uncertain,
                "is_historical": ent._.is_historical,
                "is_family": ent._.is_family,

                # ---- privacy ----
                "is_phi": ent._.is_phi,
                
            })

        for s in doc._.sections:
            def resolve(span_ref):
                if not span_ref:
                    return None
                start, end = span_ref
                if hasattr(start, "text"):
                    return start
                if isinstance(start, int):
                    return doc[start:end]
                return None

            title = resolve(s.title_span)
            body = resolve(s.body_span)

            analysis["sections"].append({
                "category": s.category,
                "title": title.text if title else "",
                "text": body.text[:100] if body else ""
            })

        return analysis


    # =====================================================
    # SCORING
    # =====================================================

    def compute_ner_scores(self, med: Dict) -> Dict[str, float]:
        scores = {
            "PatientTriage": 0.0,
            "ClinicalDecisionSupport": 0.0,
            "BillingAndClaims": 0.0,
        }

        for ent in med["entities"]:
            cat = ent.get("category")
            if cat in scores:
                scores[cat] += 1.0
            if ent["label"] == "URGENCY":
                scores["PatientTriage"] += 2.0
            if ent["label"] == "SAFETY":
                scores["ClinicalDecisionSupport"] += 2.0

        max_score = max(scores.values()) or 1.0
        return {k: round(v / max_score, 3) for k, v in scores.items()}


    def compute_semantic_scores(self, text: str) -> Dict[str, float]:
        emb = self.semantic_model.encode([text])[0]
        return {
            k: float(np.max(cosine_similarity([emb], ex_emb)))
            for k, ex_emb in self.exemplar_embeddings.items()
        }


    # =====================================================
    # CLASSIFY
    # =====================================================

    def classify(self, text: str, threshold: float = 0.35) -> ClassificationResult:
        med = self.analyze_with_medspacy(text)
        ner_scores = self.compute_ner_scores(med)
        semantic_scores = self.compute_semantic_scores(text)

        combined_scores = {
            k: 0.6 * ner_scores[k] + 0.4 * semantic_scores[k]
            for k in ner_scores
        }

        best = max(combined_scores, key=combined_scores.get)
        confidence = combined_scores[best]

        if confidence < threshold:
            best = "Unknown"
            confidence = 0.0

        # --------------------------------------------------
        # ✅ CLINICAL CONTEXT (TEST-CONTRACT SAFE)
        # --------------------------------------------------
        phi_entities = [e for e in med["entities"] if e.get("is_phi")]
        sections_detected = list(
            {s["category"] for s in med["sections"] if s.get("category")}
        )

        clinical_context = {
            "is_phi": len(phi_entities) > 0,
            "phi_count": len(phi_entities),
            "sections_detected": sections_detected,
            "has_negation": any(e["is_negated"] for e in med["entities"]),
            "has_uncertainty": any(e["is_uncertain"] for e in med["entities"]),
            "has_historical": any(e["is_historical"] for e in med["entities"]),
        }

        return ClassificationResult(
            request_type=best,
            confidence=confidence,
            entities=med["entities"],
            matched_rules=[e["text"] for e in med["entities"]],
            clinical_context=clinical_context,
            scoring_breakdown={
                "ner_scores": ner_scores,
                "semantic_scores": semantic_scores,
                "combined_scores": combined_scores,
            },
        )



# =========================================================
# WORKFLOW HELPER
# =========================================================

def classify_clinical_request(text: str) -> Dict:
    clf = PureClinicalNLPClassifier()
    result = clf.classify(text)

    return {
        "request_type": result.request_type,
        "confidence": result.confidence,
        "entities": result.entities,
        "clinical_context": result.clinical_context,
        "scoring": result.scoring_breakdown,
        "method": "pure_clinical_nlp",
    }
