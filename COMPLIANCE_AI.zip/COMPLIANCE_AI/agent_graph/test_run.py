from agent_graph.graph import build_graph
from policy_generator.policy_graph.policy_engine.enforcement_plan import build_enforcement_plan

app = build_graph()

state = {
    "request_type": "Patient Triage",
    "regulation": "HIPAA",
    "user_role": "patient",
    "input_text": "John Doe, 45, diabetic with chest pain",
    "enforcement_plan": build_enforcement_plan("PatientTriage"),
    "masked_input": "",
    "llm_output": "",
    "final_output": "",
    "audit_log": []
}

result = app.invoke(state)
print(result["final_output"])
print(result["audit_log"])
