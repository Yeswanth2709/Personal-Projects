import re

def mask_phi(text: str) -> str:
    # Mask names (very basic example)
    text = re.sub(r"\b[A-Z][a-z]+ [A-Z][a-z]+\b", "PATIENT_NAME", text)

    # Mask age
    text = re.sub(r"\b\d{1,3}\b", "AGE", text)

    return text
