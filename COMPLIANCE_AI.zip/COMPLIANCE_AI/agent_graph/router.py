def router_node(state):
    # Initialize execution queue only once
    if state.get("execution_queue"):
        return state

    steps = state["enforcement_plan"]["enforcement_steps"]
    queue = []

    # -----------------------------
    # Build execution queue
    # -----------------------------
    for step in steps:
        agent = step["agent"]
        queue.append(agent)

        # Inject LLM task after privacy enforcement
        if agent == "PrivacyAgent":
            queue.append("TASK")

    # -----------------------------
    # Mandatory post-LLM safety
    # -----------------------------
    if "OutputGuardAgent" not in queue:
        if "TASK" in queue:
            queue.insert(queue.index("TASK") + 1, "OutputGuardAgent")
        else:
            queue.append("OutputGuardAgent")

    # -----------------------------
    # Initialize policy trace map
    # -----------------------------
    state["policy_trace_map"] = {
        step["agent"]: step.get("policy_trace", [])
        for step in steps
    }

    state["execution_queue"] = queue
    return state
