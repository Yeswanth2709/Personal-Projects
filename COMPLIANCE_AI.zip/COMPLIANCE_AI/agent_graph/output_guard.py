def redact_phi(text: str) -> str:
    banned_terms = ["John", "Doe"]

    for term in banned_terms:
        text = text.replace(term, "[REDACTED]")

    return text
