from agent_graph.privacy_agent import mask_phi
from agent_graph.output_guard import redact_phi
from datetime import datetime


def access_control_node(state):
    agent = "AccessControlAgent"

    audit_entry = {
        "agent": agent,
        "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
        "action": "check_role_permissions",
        "timestamp": datetime.utcnow().isoformat(),
        "status": "COMPLETED"
    }

    state["audit_log"].append(audit_entry)
    return state


def privacy_node(state):
    agent = "PrivacyAgent"

    original = state["input_text"]
    masked = mask_phi(original)
    state["masked_input"] = masked

    audit_entry = {
        "agent": agent,
        "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
        "action": "mask_phi",
        "input_snapshot": original,
        "output_snapshot": masked,
        "timestamp": datetime.utcnow().isoformat(),
        "status": "COMPLETED"
    }

    state["audit_log"].append(audit_entry)
    return state


def task_node(state):
    # Not a governance agent
    state["llm_output"] = f"Triage result based on: {state['masked_input']}"
    return state


def output_guard_node(state):
    agent = "OutputGuardAgent"

    cleaned = redact_phi(state["llm_output"])
    state["final_output"] = cleaned

    audit_entry = {
        "agent": agent,
        "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
        "action": "scan_and_redact_output",
        "input_snapshot": state["llm_output"],
        "output_snapshot": cleaned,
        "timestamp": datetime.utcnow().isoformat(),
        "status": "COMPLETED"
    }

    state["audit_log"].append(audit_entry)
    return state


def audit_node(state):
    agent = "AuditAgent"

    audit_entry = {
        "agent": agent,
        "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
        "action": "record_policy_execution",
        "final_output_snapshot": state.get("final_output"),
        "timestamp": datetime.utcnow().isoformat(),
        "status": "COMPLETED"
    }

    state["audit_log"].append(audit_entry)

    print("Final Audit Entry:")
    print(audit_entry)

    return state
