from langchain_openai import ChatOpenAI 
import os 
import httpx 
client = httpx.Client(verify=False)
llm = ChatOpenAI(
base_url="https://genailab.tcs.in",
model = "azure/genailab-maas-gpt-4o",
api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
http_client = client
)
result=llm.invoke("Hi")
print(result)
print("WORKED")