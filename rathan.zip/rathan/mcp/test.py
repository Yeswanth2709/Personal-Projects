import requests
import asyncio

a = requests.get("http://172.25.86.246:8009")

print(a)