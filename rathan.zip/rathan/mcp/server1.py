from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Weather")

@mcp.tool()
async def get_weather(city:str)->str:
    """Return a mock weather report for a given city."""
    return f"The weather in {city} is sunny with a high of 75 F"

if __name__=="__main__":
    mcp.run(transport="stdio")
    