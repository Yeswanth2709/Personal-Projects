from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI 
import os 
import asyncio
import httpx 

client = httpx.Client(verify=False)


async def main():
    mcp_client = MultiServerMCPClient({
        "math":{
            "command":"python",
            "args":["server.py"],
            "transport":"stdio"
        },
        "weather":{
            "command":"python",
            "args":["server1.py"],
            "transport":"stdio"
        }
    })
    
    tools = await mcp_client.get_tools()
    llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model = "azure/genailab-maas-gpt-4o",
    api_key="sk-QibkR-xrOxD2AsMgdaL0Pg",
    http_client = client,
    http_async_client = httpx.AsyncClient(verify=False)
    )
    
    agent = create_agent(llm,tools)
    math_response = await agent.ainvoke({"messages":[{"role":"user","content":"What is (3+5)*2?"}]})
    print(math_response["messages"][-1].content)
    
    weather_response = await agent.ainvoke({"messages":[{"role":"user","content":"What is the weather in new york city?"}]})
    print(weather_response["messages"][-1].content)
    
    
asyncio.run(main())
        
print("Worked")